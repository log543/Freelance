import React, { useState, useEffect } from 'react';
import axios from 'axios';

const Dashboard = () => {
  const [user, setUser] = useState(null);
  const [activeTab, setActiveTab] = useState('services');
  const [userServices, setUserServices] = useState([]);
  const [userProjects, setUserProjects] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchUserData();
  }, []);

  const fetchUserData = async () => {
    try {
      const token = localStorage.getItem('token');
      const config = {
        headers: { Authorization: `Bearer ${token}` }
      };

      const userResponse = await axios.get('http://localhost:5000/api/users/profile', config);
      setUser(userResponse.data);

      const servicesResponse = await axios.get('http://localhost:5000/api/services/user', config);
      setUserServices(servicesResponse.data);

      const projectsResponse = await axios.get('http://localhost:5000/api/projects/user', config);
      setUserProjects(projectsResponse.data);

      setLoading(false);
    } catch (error) {
      console.error('Error fetching user data:', error);
      setLoading(false);
    }
  };

  if (loading) {
    return <div className="loading">Loading...</div>;
  }

  return (
    <div className="dashboard">
      <div className="dashboard-header">
        <h1>Welcome, {user?.username}!</h1>
        <div className="user-stats">
          <div className="stat-card">
            <h3>Services</h3>
            <p>{userServices.length}</p>
          </div>
          <div className="stat-card">
            <h3>Projects</h3>
            <p>{userProjects.length}</p>
          </div>
        </div>
      </div>

      <div className="dashboard-tabs">
        <button
          className={`tab ${activeTab === 'services' ? 'active' : ''}`}
          onClick={() => setActiveTab('services')}
        >
          My Services
        </button>
        <button
          className={`tab ${activeTab === 'projects' ? 'active' : ''}`}
          onClick={() => setActiveTab('projects')}
        >
          My Projects
        </button>
      </div>

      <div className="dashboard-content">
        {activeTab === 'services' ? (
          <div className="services-list">
            {userServices.map(service => (
              <div key={service._id} className="dashboard-card">
                <h3>{service.title}</h3>
                <p>{service.description}</p>
                <div className="card-footer">
                  <span className="price">${service.price}</span>
                  <div className="card-actions">
                    <button className="btn btn-secondary">Edit</button>
                    <button className="btn btn-danger">Delete</button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="projects-list">
            {userProjects.map(project => (
              <div key={project._id} className="dashboard-card">
                <h3>{project.title}</h3>
                <p>{project.description}</p>
                <div className="card-footer">
                  <span className="status">Status: {project.status}</span>
                  <div className="card-actions">
                    <button className="btn btn-secondary">Edit</button>
                    <button className="btn btn-danger">Delete</button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default Dashboard; 