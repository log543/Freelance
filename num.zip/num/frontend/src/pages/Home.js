import React from 'react';
import { Link } from 'react-router-dom';
import '../styles/Home.css';

const Home = () => {
  return (
    <div className="home">
      <section className="hero">
        <h1>Find the Perfect Freelance Services</h1>
        <p>Connect with talented freelancers and get your projects done</p>
        <div className="hero-buttons">
          <Link to="/services" className="btn btn-primary">Find Services</Link>
          <Link to="/projects" className="btn btn-secondary">Post a Project</Link>
        </div>
      </section>

      <section className="features">
        <h2>How It Works</h2>
        <div className="features-grid">
          <div className="feature-card">
            <i className="fas fa-search"></i>
            <h3>Browse Services</h3>
            <p>Find the perfect service for your needs</p>
          </div>
          <div className="feature-card">
            <i className="fas fa-file-alt"></i>
            <h3>Post Projects</h3>
            <p>Let freelancers find you</p>
          </div>
          <div className="feature-card">
            <i className="fas fa-handshake"></i>
            <h3>Collaborate</h3>
            <p>Work together seamlessly</p>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home; 