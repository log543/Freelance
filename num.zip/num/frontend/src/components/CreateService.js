import React, { useState } from 'react';
import axios from 'axios';

const CreateService = () => {
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    category: '',
    price: '',
    deliveryTime: '',
    tags: ''
  });

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    try {
      const token = localStorage.getItem('token');
      const config = {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      };

      // Convert tags string to array
      const serviceData = {
        ...formData,
        tags: formData.tags.split(',').map(tag => tag.trim()),
        price: Number(formData.price),
        deliveryTime: Number(formData.deliveryTime)
      };

      await axios.post('http://localhost:5000/api/services', serviceData, config);
      // Reset form or redirect
      setFormData({
        title: '',
        description: '',
        category: '',
        price: '',
        deliveryTime: '',
        tags: ''
      });
      alert('Service created successfully!');
    } catch (error) {
      console.error('Error creating service:', error);
      alert('Error creating service');
    }
  };

  return (
    <div className="create-service-form">
      <h2>Create a New Service</h2>
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label>Title</label>
          <input
            type="text"
            name="title"
            value={formData.title}
            onChange={handleChange}
            required
          />
        </div>

        <div className="form-group">
          <label>Description</label>
          <textarea
            name="description"
            value={formData.description}
            onChange={handleChange}
            required
          />
        </div>

        <div className="form-group">
          <label>Category</label>
          <select
            name="category"
            value={formData.category}
            onChange={handleChange}
            required
          >
            <option value="">Select Category</option>
            <option value="web-development">Web Development</option>
            <option value="design">Design</option>
            <option value="writing">Writing</option>
            <option value="marketing">Marketing</option>
          </select>
        </div>

        <div className="form-group">
          <label>Price ($)</label>
          <input
            type="number"
            name="price"
            value={formData.price}
            onChange={handleChange}
            required
          />
        </div>

        <div className="form-group">
          <label>Delivery Time (days)</label>
          <input
            type="number"
            name="deliveryTime"
            value={formData.deliveryTime}
            onChange={handleChange}
            required
          />
        </div>

        <div className="form-group">
          <label>Tags (comma-separated)</label>
          <input
            type="text"
            name="tags"
            value={formData.tags}
            onChange={handleChange}
            placeholder="e.g., wordpress, responsive, mobile"
          />
        </div>

        <button type="submit">Create Service</button>
      </form>
    </div>
  );
};

export default CreateService; 