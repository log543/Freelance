// Wait for the DOM to be fully loaded before running any code
document.addEventListener('DOMContentLoaded', function() {
    console.log('DOM fully loaded');

    // Form validation functions
    function validateEmail(email) {
        const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return re.test(email);
    }

    // Form handlers
    function handleLogin(event) {
        event.preventDefault();
        console.log('Login handler called');
        
        const email = document.getElementById('loginEmail').value;
        const password = document.getElementById('loginPassword').value;

        // Get users from localStorage
        const users = JSON.parse(localStorage.getItem('users')) || [];
        const user = users.find(u => u.email === email && u.password === password);

        if (user) {
            localStorage.setItem('currentUser', JSON.stringify(user));
            alert('Login successful!');
            closeModal('loginModal');
            window.location.reload();
        } else {
            alert('Invalid email or password');
        }
        
        return false;
    }

    function handleRegister(event) {
        event.preventDefault();
        console.log('Register handler called');
        
        const username = document.getElementById('registerUsername').value;
        const email = document.getElementById('registerEmail').value;
        const password = document.getElementById('registerPassword').value;
        const userType = document.getElementById('userType').value;

        // Get existing users
        const users = JSON.parse(localStorage.getItem('users')) || [];
        
        // Check if email exists
        if (users.some(user => user.email === email)) {
            alert('Email already registered');
            return false;
        }

        // Add new user
        const newUser = {
            username,
            email,
            password,
            userType
        };

        users.push(newUser);
        localStorage.setItem('users', JSON.stringify(users));
        
        alert('Registration successful! Please login.');
        switchModal('registerModal', 'loginModal');
        
        return false;
    }

    // Modal functions
    window.openModal = function(modalId) {
        console.log('Opening modal:', modalId);
        document.getElementById(modalId).style.display = 'block';
    }

    window.closeModal = function(modalId) {
        console.log('Closing modal:', modalId);
        document.getElementById(modalId).style.display = 'none';
    }

    window.switchModal = function(closeModalId, openModalId) {
        closeModal(closeModalId);
        openModal(openModalId);
    }

    // Attach form handlers to window object so they can be called from HTML
    window.handleLogin = handleLogin;
    window.handleRegister = handleRegister;

    // Check login status
    const currentUser = JSON.parse(localStorage.getItem('currentUser'));
    if (currentUser) {
        const loginBtn = document.querySelector('button.nav-btn');
        const registerBtn = document.querySelector('button.register-btn');
        
        if (loginBtn && registerBtn) {
            loginBtn.textContent = `Welcome, ${currentUser.username}`;
            registerBtn.textContent = 'Logout';
            registerBtn.onclick = function() {
                localStorage.removeItem('currentUser');
                window.location.reload();
            };
        }
    }

    // Close modal when clicking outside
    window.onclick = function(event) {
        if (event.target.classList.contains('modal')) {
            closeModal(event.target.id);
        }
    }

    console.log('Script initialization complete');
});