import React, { useState, useEffect } from 'react';
import axios from 'axios';

const ServicesList = () => {
  const [services, setServices] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchServices = async () => {
      try {
        const response = await axios.get('http://localhost:5000/api/services');
        setServices(response.data);
        setLoading(false);
      } catch (error) {
        console.error('Error fetching services:', error);
        setLoading(false);
      }
    };

    fetchServices();
  }, []);

  if (loading) return <div>Loading...</div>;

  return (
    <div className="services-grid">
      {services.map((service) => (
        <div key={service._id} className="service-card">
          <h3>{service.title}</h3>
          <p>{service.description}</p>
          <div className="service-details">
            <span>Price: ${service.price}</span>
            <span>Delivery: {service.deliveryTime} days</span>
          </div>
          <div className="service-tags">
            {service.tags.map((tag, index) => (
              <span key={index} className="tag">
                {tag}
              </span>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
};

export default ServicesList; 